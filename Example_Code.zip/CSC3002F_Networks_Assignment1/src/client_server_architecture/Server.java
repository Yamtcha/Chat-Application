/***
 * An implementation of a Server to service connections of clients of a Chat Application.
 * @author Pieter Janse van Rensburg (JNSPIE007)
 * @version 1.0.0
 * @date 2017/03/25
 */


package client_server_architecture;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class Server implements Runnable {
	// The Port to be Used by the Server to Listen for Incoming Connections
	public final static int INCOMING_CONNECTION_PORT = 1337;
	
	// instance variables
	private ServerSocket serverSocket;
	
	/***
	 * Constructor of the Server Class.
	 * @see Server#intializeServer()
	 */
	public Server() {


		this.intializeServer();
	}
	
	
	/***
	 * This method is used to create a Server Socket which listens to and accepts connections from clients.
	 * If this cannot be done an {@link IOException} is caught.
	 */
	private void intializeServer() {
		// sets up server Socket to listen for and deal with incoming client connections
		try {
			this.serverSocket = new ServerSocket(INCOMING_CONNECTION_PORT);
		} catch (IOException e) {
			// if it fails an error is printed out and the program returns because the server cannot be started.
			System.out.println(e);
		}
		
		System.out.println("Server Starting & Waiting for Connections on Port " + INCOMING_CONNECTION_PORT + ":");

	}
	
	/***
	 * A loop used to listen for client connections on the server's open  to accept 
	 * client requests and initializes a socket to send/receive data from the client.
	 */
	private void listenForConnections() {
			// Server is always listening for connections
			Socket clientSocket = null;
			while(true) {
				try {
					// Accept connection from client and assign clientSocket to the connection in parallel
					clientSocket = this.serverSocket.accept();
				} catch (IOException e) {
					System.out.println(e);
					}
					// create new thread to service client connection
					ClientInteractionHandler currentClient = new ClientInteractionHandler(clientSocket,null,true);
					new Thread(currentClient).start();
			}
			
	}
	
	
	/***
	 * This method is used to shut down the Server Socket.
	 * If this cannot be done an {@link IOException} is caught.
	 */
	public void shutDownServer() {
		try {
			this.serverSocket.close();
		} catch (IOException e) {
			System.out.println(e);
		}
		System.out.println("Server no longer listening for connections");
	}
	
	@Override
	public void run() {
		this.listenForConnections();
		
	}
	
	
	
	
	
	
	
	
	
		
public class ClientInteractionHandler implements Runnable{

		
		private Socket connectionToClient;
		private Message message;
		private boolean download;
		
		public ClientInteractionHandler(Socket clientSocket, Message message, boolean download) {
			this.connectionToClient = clientSocket;
			this.message = message;
			this.download = download;
		}
		
		public boolean isDownload() {
			return this.download;
		}
		
		public void setDownload(boolean download) {
			this.download = download;
		}
		
		
		public Message getInputFromClient() {
			
			// Gets Input from Client and stores it as a 1 line String
			Message message = null;
			ObjectInputStream input;
			try {
			input = new ObjectInputStream(this.connectionToClient.getInputStream());
			message = new Message(input.readByte(), input.readUTF(), input.readUTF(), input.readObject());
			
			} catch (IOException | ClassNotFoundException e) {
				System.out.println(e);
			} 
			
			return message;

			}
		
		public void sendOutputToClient(Message message) {
			// Send output to the Client
			ObjectOutputStream output;
			try {
				output = new ObjectOutputStream(this.connectionToClient.getOutputStream());
				
				output.writeByte(message.getMessageID());
				output.writeUTF(message.getSourceName());
				output.writeUTF(message.getDestinationName());
				if(message.getMessageID() == 0 || message.getMessageID() == 1)
					output.writeObject(message.getData().toString());
				else
					output.writeObject(((BufferedImage)message.getData()));
				
				output.flush();
				
			} catch (IOException e) {
				System.out.println(e);
			}
		}
		
		public boolean isCorrectDetails(String username, String password) {
			return false;
		}

		@Override
		public void run() {
			if(this.isDownload()) {
				this.message = this.getInputFromClient();
				switch(this.message.getMessageID()) {
					case 0: {
						byte messageID = this.message.getMessageID();
						String destinationName = this.message.getSourceName();
						String sourceName = "Server";
						if(isCorrectDetails(this.message.getSourceName(), this.message.getData().toString()))
							this.message = new Message(messageID, sourceName, destinationName, "true");
						else
							this.message = new Message(messageID, sourceName, destinationName, "false");
							
						this.sendOutputToClient(message);
						break;
						}
					case 1: {
						System.out.println(this.message.getData().toString());
						this.sendOutputToClient(message);
						break;
						}
					case 2: {
						
						this.sendOutputToClient(message);
						break;
						}
					default: {
						
						break;
						}
				
					}

				
				
				
				
				}
			else {
				this.sendOutputToClient(this.message);
			}
			
			


		
		
			}
		
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

		
	
	
}
