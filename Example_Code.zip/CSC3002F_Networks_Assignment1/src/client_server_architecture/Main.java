/***
 * Main Class for Client-Server Architecture Assignment
 * @author Pieter Janse van Rensburg (JNSPIE007)
 * @version 1.0.0
 * @date 2017/03/25
 */
package client_server_architecture;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class Main {
	
	// Menu to be shown to the user
	private final static String MENU = "Please Enter 1, 2 or Exit to Chose From the Following Options:\n"
			+ "1. - Send a Text Message to Another Client\n"
			+ "2. - Send an Image to Another Client\n"
			+ "3. - Download Text Messages for this Client\n"
			+ "4. - Download Images for this Client"
			+ "Exit. - Exit the Client and Shutdown the Server"; 
	
	
	/***
	 * Main method of the project.
	 * @param args Command Line parameters supplied by the user.
	 */
	public static void main(String args[]) {
		// initialize server and start in a new thread to listen for connections
		Server server = new Server();
		new Thread(server).start();
		// initialize the current user's client
		Client client1 = new Client();
		// initialize another client for testing purposes
		Client client2 = new Client("J", "P");
		// make the other client send input in a separate thread
		new Thread(client2).start();
		//print out the menu and ask for user input
		
		System.out.println(MENU);
		Scanner input = new Scanner(System.in);
		String choice = "";
		if(input.hasNext())
			 choice = input.nextLine();
		
		while(!choice.equals("Exit")) {
			
			switch (choice) {
			case "1":{
				System.out.println("Please enter the ID of the Client to send the message to.");
				int destinationID = Integer.parseInt(input.nextLine());
				System.out.println("Please enter the Message to Send to Them");
				String outMessage = input.nextLine() + "\n";
				System.out.println(outMessage);
				
				break;
				}
			case "2":{
				System.out.println("Please enter the ID of the Client to send the message to.");
				int destinationID = Integer.parseInt(input.nextLine());
				System.out.println("Please enter the location of the Image to be sent");
				// Gets Image From Computer File System
				try {
				BufferedImage outImage = ImageIO.read(new File(input.nextLine()));
				} catch (IOException e) {
					System.out.println(e);
				}
				break;
			}
			default: {
				System.out.println("Incorrect Input Please enter another choice.");
				break;
				}
			}
			
			
			System.out.println(MENU);
			choice = input.nextLine();
			
			}
		input.close();
		System.exit(0);
		
	}
	
}
