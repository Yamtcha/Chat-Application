package client_server_architecture;

import java.awt.image.BufferedImage;

public class Message {

	// request codes to be interpreted by the server and clients.
	private static final byte REGISTRATION_REQUEST = 0;
	private static final byte TEXT_TRANSFER_REQUEST = 1;
	private static final byte IMAGE_TRANSFER_REQUEST = 2;
	//instance variables
	private byte messageID;
	private String sourceName;
	private String destinationName;
	private Object data;
	
	
	public Message(String sourceName, String password) {
		this.messageID = REGISTRATION_REQUEST;
		this.sourceName = sourceName;
		this.destinationName = "";
		this.data = password;
		}
	
	public Message(String sourceName, String destinationName, Object message) {
		if(message.getClass().equals(String.class))
			this.textMessage(sourceName, destinationName, message.toString());
		else if (message.getClass().equals(BufferedImage.class))
			this.imageMessage(sourceName, destinationName, ((BufferedImage)message));
		else
			System.out.println("Invalid Message Error");
			
	}
	
	public Message(byte messageID, String sourceName, String destinationName, Object data) {
		this.messageID = messageID;
		this.sourceName = sourceName;
		this.destinationName = destinationName;
		this.data = data;
		
		
		}
	
	public void textMessage(String sourceName, String destinationName, String textMessage) {
		this.messageID = TEXT_TRANSFER_REQUEST;
		this.sourceName = sourceName;
		this.destinationName = destinationName;
		this.data = textMessage;
	}
	
	public void imageMessage(String sourceName, String destinationName, BufferedImage imageMessage) {
		this.messageID = IMAGE_TRANSFER_REQUEST;
		this.sourceName = sourceName;
		this.destinationName = destinationName;
		this.data = imageMessage;
	}
	
	public byte getMessageID() {
		return this.messageID;
	}
	
	public void setMessageID(byte messageID) {
		this.messageID = messageID;
	}
	
	public String getSourceName() {
		return this.sourceName;
	}
	
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	
	public String getDestinationName() {
		return this.destinationName;
	}
	
	public void setDestinationName(String destinationName) {
		this.destinationName = destinationName;
	}
	
	public Object getData() {
		return this.data;
	}
	
}
