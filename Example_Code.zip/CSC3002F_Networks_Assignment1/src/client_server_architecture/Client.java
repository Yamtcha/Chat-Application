/***
 * An implementation of a Chat Client
 * @author Pieter Janse van Rensburg (JNSPIE007)
 * @version 1.0.0
 * @date 2017/03/25
 */
package client_server_architecture;


import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.LinkedBlockingQueue;


public class Client implements Runnable {
	
	// Static variable Used to Ensure that Each Client has a Unique ID
	private final static String USER_DETAILS_FILE = "User_Details.txt";
	private final static char DETAIL_SEPERATOR = '#';
	// instance variables
	private String username;
	private String password;
	private Socket myClient;
	private LinkedBlockingQueue<Object> allMessages;
	
	/***
	 * Constructor of the Client Class Uses the variable CLIENT_ID to ensure that each client has a unique ID.
	 * @see Client#CLIENT_ID
	 */
	public Client() {
		this.setUpConnectionToServer("localhost");
		// Check if User Detail File Exists
		File file = new File(USER_DETAILS_FILE);
		// if it does load User Details from file.
		if(file.exists()){
			loadUserDataFromFile();
			checkCredentials(this.username, this.password);
			}
		else {
			// If it doesn't then ask the User to Input user name and Password
			
			Scanner input = new Scanner(System.in);
			this.username = "";
			this.password = "";
			do {
				System.out.println("Please enter a Username:");
				this.username = input.nextLine();
				System.out.println("Please enter a Password:");
				this.password = input.nextLine();
				} while(checkCredentials(this.username, this.password));
			
		}
		// Save User details to File
		saveUserDataToFile();

			
	}
	
	public Client(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	private void loadUserDataFromFile() {
		BufferedReader infile;
		try {
			infile = new BufferedReader(new FileReader(USER_DETAILS_FILE));
			String details = infile.readLine();
			this.username = details.substring(0, details.indexOf('#'));
			this.password = details.substring(details.indexOf('#') + 1);
		} catch (IOException e) {
			System.out.println(e);
		}

		
		
	}
	
	private void saveUserDataToFile() {
		try {
			FileWriter outfile = new FileWriter(USER_DETAILS_FILE);
			outfile.write(this.username + DETAIL_SEPERATOR + this.password);
			outfile.close();
		} catch (IOException e) {
			System.out.println(e);
		}
		
	}
	
	
	/***
	 * This method is used by the Client to Connect to the Server.
	 * If this cannot be done an {@link IOException} is caught.
	 * @param machineName The Machine Name to Open a Connection To.
	 */
	public void setUpConnectionToServer(String machineName) {
		try {
			this.myClient = new Socket(machineName, Server.INCOMING_CONNECTION_PORT);
		} catch (IOException e) {
			System.out.println(e);
		}
		
		System.out.println("Client has established connection to Server");
	}
	
	public boolean checkCredentials(String username, String password) {
		Message message = new Message(username, password);
		ServerInteractionHandler myConnection = new ServerInteractionHandler(this.myClient, message, false);
		myConnection.run();
		if(myConnection.getMessage().getData().toString().equals("true"))
		return true;
		
		return false;
	}
	
	/***
	 * This method is used to get input from a server sent to the client.
	 * {@link BufferedReader}, {@link InputStreamReader}, {@link IOException}
	 * @return inputMessage The message received from the server in the form of a String.
	 */
	public void getInputFromServer() {
		ServerInteractionHandler myConnection = new ServerInteractionHandler(this.myClient, null, true);
		new Thread(myConnection).run();
	}
	
	
	/***
	 * This method is used to send output to the server from a client.
	 * {@link PrintStream}, {@link IOException}
	 * @param outputMessage The message to send to the client in the form of a String.
	 */
	public void sendOutputToServer(String destinationName, Object outputMessage) {
		Message message = new Message(this.username, destinationName, outputMessage);
		ServerInteractionHandler myConnection = new ServerInteractionHandler(this.myClient, message, false);
		new Thread(myConnection).run();
	}
	
	/***
	 * This method is used to close the clients connection to the Server. If this cannot be done an IOException is caught.
	 * @see IOException
	 */
	public void CloseServerConnection() {
		try {
			this.myClient.close();
		} catch (IOException e) {
			System.out.println(e);
		}
	}


	@Override
	public void run() {
		try {
			Thread.sleep(2000);
			this.setUpConnectionToServer("localhost");
			this.sendOutputToServer("Jason", "-_-");
			this.getInputFromServer();
		} catch(InterruptedException e){
			System.out.println(e);
		}
		finally {
			CloseServerConnection();
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

public class ServerInteractionHandler implements Runnable{
		
	private Socket connectionToServer;
	private Message message;
	private boolean download;
	
	public ServerInteractionHandler(Socket connectionToServer, Message message, boolean download) {
		this.connectionToServer = connectionToServer;
		this.message = message;
		this.download = download;
		}
		
		
	public Message getMessage() {
		return this.message;
		}
		
	public void setMessage(Message message) {
		this.message = message;
		}
		
	public boolean isDownload() {
		return this.download;
		}
		
	public void setDownload(boolean download) {
		this.download = download;
		}	
		
	/***
	 * This method is used to get input from a server sent to the client.
	 * {@link BufferedReader}, {@link InputStreamReader}, {@link IOException}
	 * @return inputMessage The message received from the server in the form of a String.
	 */
	public Message getInputFromServer() {
	// Gets Input from Client and stores it as a 1 line String
	Message message = null;
	ObjectInputStream input;
	try {
		input = new ObjectInputStream(this.connectionToServer.getInputStream());
		message = new Message(input.readByte(), input.readUTF(), input.readUTF(), input.readObject());
						
		} catch (IOException | ClassNotFoundException e) {
			System.out.println(e);
			} finally {
				try {
					// closes the socket and the streams
					this.connectionToServer.close();
					} catch (IOException e) {
						System.out.println(e);
						}
					}
	return message;
	}
		
	
	/***
	 * This method is used to send output to the server from a client.
	 * {@link PrintStream}, {@link IOException}
	 * @param outputMessage The message to send to the client in the form of a String.
	 */
	public void sendOutputToServer(Message message) {
		// Send output to the Server in the form of a 1 line String
		ObjectOutputStream output;
		try {
			output = new ObjectOutputStream(this.connectionToServer.getOutputStream());
				
			output.writeByte(message.getMessageID());
			output.writeUTF(message.getSourceName());
			output.writeUTF(message.getDestinationName());
			if(message.getMessageID() == 0 || message.getMessageID() == 1)
				output.writeObject(message.getData().toString());
			else
				output.writeObject(((BufferedImage)message.getData()));
				
			output.flush();
				
		} catch (IOException e) {
			System.out.println(e);
		}
	}
		
	/***
	 * This method is used to close the clients connection to the Server. If this cannot be done an IOException is caught.
	 * @see IOException
	 */
	public void CloseServerConnection() {
		try {
			this.connectionToServer.close();
			} catch (IOException e) {
				System.out.println(e);
				}
		}

		
	@Override
	public void run() {
		if(this.isDownload()){
			this.message = this.getInputFromServer();
			System.out.println(this.message.getData().toString());			
			}
		else {
			this.sendOutputToServer(this.message);
			switch(this.message.getMessageID()){
				case 0: {
					this.message = this.getInputFromServer();
					}
				default: {
					System.out.println("Message sent to server successfully");
					break;
					}
				
				}
					
			}
		}
		
	}	
	
	
	
	
	
}
